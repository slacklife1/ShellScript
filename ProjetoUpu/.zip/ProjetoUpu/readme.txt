 #######################################################
#	Universal Packing Unpacking Linux		#
#							#
#	por Felipe Vieira<slacklife@gmail.com>		#
#           Romulo Reis<reisinfante@gmail.com>    	#
#							#
#	Janeiro de 2020					#
#	Versao: 1.1.0					#
#							#
 #######################################################

INFORMAÇÕES:


makefile		<--- Script de Instalção do Universal Packing Unpacking Linux
upu.sh			<--- Script do upu


DESCRIÇÃO DE USO:

	Para o uso da Compactação de arquivo

		upu [ARQUIVO]

	Para a Descompactação de Arquivo (.zip, .rar, .tar, .bz2, .tar.bz2)

		upu [ARQUIVO.ALGO]


INSTALAÇÃO:

	./makefile




